# Manual gráfico del sistema — "El Patojismo" (proyecto APP ANDO)

Capturas de **todas las pantallas del sistema**, una por cada sección de los tres
portales, tomadas del sistema real corriendo en local (`http://localhost:5173`).
Rama: `fase-15-formatos-institucionales` (UI mobile-first + formatos institucionales).

- **Carpeta de imágenes:** `capturas/` (53 archivos `.png`, pantalla completa).
- **Roles usados:** Dirección (`dir.demo`), Docente (`docente.demo`), Docente con
  sección a cargo / guía (`guia.demo`), Tallerista (`tallerista.demo`) y Padre de
  familia (`familia.demo`). Contraseña de siembra: `CambiaEstaClave2026`.
- **Convención de nombres:** `NN-portal-seccion-detalle.png` (NN = orden).
- **Formato:** 01–47 en escritorio (1440×900); 48–53 (portal de familias) en
  **formato celular** (390×844 px @3×), porque ese portal es de diseño móvil.

**Marco visual común (fase 14/15):** cabecera de página con título y acciones,
tarjetas con esquinas redondeadas y sombra suave, botones azules (`#1c6ea4`),
tipografías Archivo (títulos) y Public Sans (cuerpo), etiquetas de estado de color,
barra lateral con iconos en los portales de escritorio y navegación inferior con
iconos en el portal de familias.

---

## Resumen (para clasificar en el documento)

| # | Archivo | Portal | Sección | Rol |
|---|---|---|---|---|
| 1 | 01-publico-ingreso-login.png | Público | Ingreso (login) | — |
| 2 | 02-publico-verificacion-documento-qr.png | Público | Verificación de documento | — |
| 3 | 03-administrativo-inicio.png | Administrativo | Inicio | Dirección |
| 4 | 04-administrativo-datos-maestros-menu.png | Administrativo | Datos maestros (índice) | Dirección |
| 5 | 05-administrativo-datos-maestros-ciclos.png | Administrativo | Datos maestros → Ciclos y unidades | Dirección |
| 6 | 06-administrativo-datos-maestros-secciones.png | Administrativo | Datos maestros → Secciones | Dirección |
| 7 | 07-administrativo-datos-maestros-cursos.png | Administrativo | Datos maestros → Cursos | Dirección |
| 8 | 08-administrativo-datos-maestros-tipos-actividad.png | Administrativo | Datos maestros → Tipos de actividad | Dirección |
| 9 | 09-administrativo-datos-maestros-tipos-justificacion.png | Administrativo | Datos maestros → Tipos de justificación | Dirección |
| 10 | 10-administrativo-datos-maestros-tipos-documento.png | Administrativo | Datos maestros → Tipos de documento | Dirección |
| 11 | 11-administrativo-datos-maestros-becas.png | Administrativo | Datos maestros → Becas | Dirección |
| 12 | 12-administrativo-datos-maestros-articulos.png | Administrativo | Datos maestros → Artículos de convivencia | Dirección |
| 13 | 13-administrativo-estudiantes-listado.png | Administrativo | Estudiantes | Dirección |
| 14 | 14-administrativo-expediente.png | Administrativo | Expediente del estudiante | Dirección |
| 15 | 15-administrativo-encargados.png | Administrativo | Encargados | Dirección |
| 16 | 16-administrativo-asignaciones.png | Administrativo | Asignaciones | Dirección |
| 17 | 17-administrativo-plantilla-talleres.png | Administrativo | Plantilla de talleres | Dirección |
| 18 | 18-administrativo-asistencia.png | Administrativo | Asistencia (tomar) | Dirección |
| 19 | 19-administrativo-justificaciones.png | Administrativo | Justificaciones | Dirección |
| 20 | 20-administrativo-notas-modificaciones.png | Administrativo | Modificaciones de notas | Dirección |
| 21 | 21-administrativo-pagos.png | Administrativo | Pagos y solvencia | Dirección |
| 22 | 22-administrativo-documentos.png | Administrativo | Documentos emitidos | Dirección |
| 23 | 23-administrativo-boletines.png | Administrativo | Boletines | Dirección |
| 24 | 24-administrativo-horarios.png | Administrativo | Horarios | Dirección |
| 25 | 25-administrativo-calendario.png | Administrativo | Calendario | Dirección |
| 26 | 26-administrativo-avisos.png | Administrativo | Avisos | Dirección |
| 27 | 27-administrativo-reportes-conducta.png | Administrativo | Reportes de conducta | Dirección |
| 28 | 28-administrativo-buzon.png | Administrativo | Buzón | Dirección |
| 29 | 29-administrativo-reportes.png | Administrativo | Reportes institucionales | Dirección |
| 30 | 30-administrativo-usuarios.png | Administrativo | Usuarios | Dirección |
| 31 | 31-administrativo-bitacora.png | Administrativo | Bitácora | Dirección |
| 32 | 32-administrativo-cuenta.png | Administrativo | Mi cuenta | Dirección |
| 33 | 33-administrativo-metricas.png | Administrativo | Métricas del estudio | Dirección |
| 34 | 34-operativo-inicio.png | Operativo | Inicio | Docente |
| 35 | 35-operativo-asistencia.png | Operativo | Asistencia (tomar) | Docente |
| 36 | 36-operativo-justificaciones.png | Operativo | Justificaciones | Docente |
| 37 | 37-operativo-mi-horario.png | Operativo | Mi horario | Docente |
| 38 | 38-operativo-calendario.png | Operativo | Calendario | Docente |
| 39 | 39-operativo-avisos.png | Operativo | Avisos | Docente |
| 40 | 40-operativo-notas-unidad.png | Operativo | Notas → Diseñar unidad | Docente |
| 41 | 41-operativo-notas-capturar.png | Operativo | Notas → Capturar notas | Docente |
| 42 | 42-operativo-notas-plantilla.png | Operativo | Notas → Plantilla de notas | Docente |
| 43 | 43-operativo-notas-modificaciones.png | Operativo | Notas → Modificaciones | Docente |
| 44 | 44-operativo-cuenta.png | Operativo | Mi cuenta | Docente |
| 45 | 45-operativo-reportes-conducta.png | Operativo | Reportes de conducta | Guía |
| 46 | 46-operativo-buzon.png | Operativo | Buzón | Guía |
| 47 | 47-operativo-plantilla-talleres.png | Operativo | Plantilla de talleres | Tallerista |
| 48 | 48-portal-familia-inicio.png | Portal público | Inicio (calendario semanal) | Familia |
| 49 | 49-portal-familia-notas.png | Portal público | Notas | Familia |
| 50 | 50-portal-familia-asistencia.png | Portal público | Asistencia | Familia |
| 51 | 51-portal-familia-pagos.png | Portal público | Pagos y solvencia | Familia |
| 52 | 52-portal-familia-cuenta.png | Portal público | Mi cuenta | Familia |
| 53 | 53-portal-familia-avisos.png | Portal público | Avisos | Familia |

---

## 1. Pantallas públicas (sin sesión)

### `01-publico-ingreso-login.png` — Ingreso al sistema (login)
- **Ruta:** `/ingresar` · **Rol:** ninguno.
- **Qué es:** formulario de autenticación único para los tres portales (Usuario,
  Contraseña y botón "Entrar"). Al validar redirige al portal que corresponde al
  rol. Muestra mensajes de error específicos (credenciales, cuenta bloqueada,
  demasiados intentos).

### `02-publico-verificacion-documento-qr.png` — Verificación pública de documento
- **Ruta:** `/verificar/<código>` · **Rol:** ninguno.
- **Qué es:** página a la que se llega al escanear el QR de un documento emitido.
  Muestra si el documento es **válido**, su tipo, el estudiante y la fecha, sin
  datos sensibles.

---

## 2. Portal administrativo (rol Dirección)

### `03-administrativo-inicio.png` — Inicio
- **Ruta:** `/administrativo`.
- **Qué es:** panel de bienvenida con saludo, resumen de pendientes (p. ej.
  solicitudes de modificación por resolver) y accesos rápidos ("Lo más usado").

### `04-administrativo-datos-maestros-menu.png` — Datos maestros (índice)
- **Ruta:** `/administrativo/catalogo`.
- **Qué es:** menú de acceso a los 8 catálogos del sistema.

### `05…` a `12…` — Los 8 catálogos
- **Ciclos y unidades** (05): ciclos escolares (año, fechas, estado) y sus unidades.
- **Secciones** (06): grupos con grado, letra, tipo (académica/taller), ciclo y maestro guía.
- **Cursos** (07): materias/talleres con nombre y tipo.
- **Tipos de actividad** (08), **tipos de justificación** (09), **tipos de documento** (10),
  **becas** (11) y **artículos de convivencia** (12): catálogos auxiliares con su
  tabla y acciones crear/editar/dar de baja.

### `13-administrativo-estudiantes-listado.png` — Estudiantes
- **Ruta:** `/administrativo/estudiantes`.
- **Qué es:** listado con búsqueda y filtros; desde cada fila se abre el expediente.

### `14-administrativo-expediente.png` — Expediente del estudiante
- **Ruta:** `/administrativo/estudiantes/<id>`.
- **Qué es:** ficha individual: datos personales editables y, aparte, **datos
  sensibles** (salud, socioeconómicos) de acceso reservado y con consulta registrada.

### `15-administrativo-encargados.png` — Encargados
- **Ruta:** `/administrativo/encargados`.
- **Qué es:** padres/tutores y su vínculo con uno o más estudiantes.

### `16-administrativo-asignaciones.png` — Asignaciones
- **Ruta:** `/administrativo/asignaciones`.
- **Qué es:** asignación de docentes y talleristas a cursos y secciones.

### `17-administrativo-plantilla-talleres.png` — Plantilla de talleres
- **Ruta:** `/administrativo/plantilla-asistencia`.
- **Qué es:** plantilla de asistencia de talleres en Excel: elegir taller y fecha,
  descargar plantilla y subirla llena.

### `18-administrativo-asistencia.png` — Asistencia (tomar)
- **Ruta:** `/administrativo/asistencia`.
- **Qué es:** toma de asistencia por sección y fecha.

### `19-administrativo-justificaciones.png` — Justificaciones
- **Ruta:** `/administrativo/justificaciones`.
- **Qué es:** registro y revisión de justificaciones de inasistencia.

### `20-administrativo-notas-modificaciones.png` — Modificaciones de notas
- **Ruta:** `/administrativo/notas/modificaciones`.
- **Qué es:** bandeja de solicitudes de modificación de notas (aprobar/rechazar).

### `21-administrativo-pagos.png` — Pagos y solvencia
- **Ruta:** `/administrativo/pagos`.
- **Qué es:** pagos por estudiante, solvencia y reporte de estudiantes insolventes.

### `22-administrativo-documentos.png` — Documentos emitidos
- **Ruta:** `/administrativo/documentos`.
- **Qué es:** constancias/cartas emitidas con su código de verificación y descarga.

### `23-administrativo-boletines.png` — Boletines
- **Ruta:** `/administrativo/boletines`.
- **Qué es:** generación, aprobación y publicación de boletines por sección y unidad.

### `24-administrativo-horarios.png` — Horarios
- **Ruta:** `/administrativo/horarios`.
- **Qué es:** grilla de bloques de horario por sección/curso/docente.

### `25-administrativo-calendario.png` — Calendario
- **Ruta:** `/administrativo/calendario`.
- **Qué es:** calendario semanal con eventos institucionales y de asignación.

### `26-administrativo-avisos.png` — Avisos
- **Ruta:** `/administrativo/avisos`.
- **Qué es:** cartelera de avisos para el centro y las familias.

### `27-administrativo-reportes-conducta.png` — Reportes de conducta
- **Ruta:** `/administrativo/reportes-conducta`.
- **Qué es:** reportes de conducta citando artículos del código de convivencia.

### `28-administrativo-buzon.png` — Buzón
- **Ruta:** `/administrativo/buzon`.
- **Qué es:** mensajes/consultas de las familias.

### `29-administrativo-reportes.png` — Reportes institucionales
- **Ruta:** `/administrativo/reportes`.
- **Qué es:** los 8 reportes (notas, asistencia, insolventes, horarios, inscritos,
  historial de modificaciones, accesos de familias, documentos emitidos) con filtros
  y descarga en PDF.

### `30-administrativo-usuarios.png` — Usuarios
- **Ruta:** `/administrativo/usuarios`.
- **Qué es:** administración de cuentas (crear con contraseña temporal, editar,
  desactivar/reactivar, restablecer contraseña) y matriz de permisos de cada rol.

### `31-administrativo-bitacora.png` — Bitácora
- **Ruta:** `/administrativo/bitacora`.
- **Qué es:** registro de cambios ("Cambios") y de accesos ("Accesos"), con filtro
  por persona y paginación.

### `32-administrativo-cuenta.png` — Mi cuenta
- **Ruta:** `/administrativo/cuenta`.
- **Qué es:** datos de la propia cuenta (solo lectura) y cambio de contraseña.

### `33-administrativo-metricas.png` — Métricas del estudio
- **Ruta:** `/administrativo/metricas`.
- **Qué es:** dos indicadores semanales agregados (procesos gestionados y uso del
  portal de familias), sin datos personales.

---

## 3. Portal operativo (docentes, guía y tallerista)

- **34** Inicio · **35** Tomar asistencia · **36** Justificaciones · **37** Mi horario ·
  **38** Calendario · **39** Avisos · **40** Diseñar unidad · **41** Capturar notas ·
  **42** Plantilla de notas · **43** Modificaciones · **44** Mi cuenta (Docente).
- **45** Reportes de conducta y **46** Buzón (Docente con sección a cargo / guía).
- **47** Plantilla de talleres (Tallerista).

Cada pantalla cumple la misma función que su homóloga administrativa, pero acotada
al alcance del rol: el docente ve solo sus cursos/secciones, el guía además los
reportes de conducta y el buzón de su sección, y el tallerista la plantilla de su
taller.

---

## 4. Portal público / familias (vista móvil)

### `48-portal-familia-inicio.png` — Inicio (calendario semanal)
- **Ruta:** `/portal` · **Rol:** Padre de familia.
- **Qué es:** portada móvil: cabecera con la marca y el estudiante, pestañas de día
  (lun–vie) y agenda de clases/avisos del día.

### `49-portal-familia-notas.png` — Notas
- **Ruta:** `/portal/notas`.
- **Qué es:** calificaciones del estudiante por curso y unidad, y descarga del boletín.

### `50-portal-familia-asistencia.png` — Asistencia
- **Ruta:** `/portal/asistencia`.
- **Qué es:** registros de asistencia (jornada y taller) con etiquetas de color, y
  reportes de conducta.

### `51-portal-familia-pagos.png` — Pagos y solvencia
- **Ruta:** `/portal/pagos`.
- **Qué es:** estado de solvencia y descarga de constancias.

### `52-portal-familia-cuenta.png` — Mi cuenta
- **Ruta:** `/portal/cuenta`.
- **Qué es:** datos propios y cambio de contraseña (mismo componente que en los otros portales).

### `53-portal-familia-avisos.png` — Avisos
- **Ruta:** `/portal/avisos`.
- **Qué es:** avisos del centro y buzón de mensajes con la sección del estudiante.
